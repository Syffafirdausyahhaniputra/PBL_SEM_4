<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Survey Kepuasan - Politeknik Negeri Malang</title>
    <link rel="stylesheet" href="../../style.css">
</head>

<body>
    <!-- Konten Anda -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../../script.js"></script>
</body>

</html>

<body>
    <header>
        <div class="container1">
            <img src="../../gambar/polinema.png" alt="Logo Politeknik Negeri Malang" class="logo">
            <div class="title-container">
                <h1>POLITEKNIK NEGERI MALANG</h1>
                <h2 class="sub-title">Survey Kepuasan</h2>
            </div>
        </div>
        <div class="container2UP"></div>
    </header>
</body>